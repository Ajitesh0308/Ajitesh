---
name: Algorithmic Inventory Telemetry
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#c0c1ff'
  on-secondary: '#1000a9'
  secondary-container: '#3131c0'
  on-secondary-container: '#b0b2ff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.5rem
  margin: 1.5rem
  margin-mobile: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The visual identity embodies an experimental algorithmic command center: mission-critical, dense, and hyper-precise. Engineered for enterprise supply chain operators, quantitative planners, and automated logistics systems, the interface mirrors high-frequency trading terminals and telemetry observation decks. 

Rather than standard SaaS softness, the design adopts an unyielding technical posture. Monospaced numeric layouts align strictly to mathematical baselines, punctuated by electric surplus green (#10B981) and tactical indigo accents against deep obsidian-slate ground planes. The emotional resonance is one of absolute operational authority, speed, and real-time computation—delivering instant situational awareness across millions of retail SKUs under variable volatility.

## Colors

The color system operates strictly in dark mode, optimizing luminance efficiency and legibility across dense data displays:

- **Primary (`#10B981` - Surplus Green):** Denotes positive yield, machine-learning confidence scores, stock stability, and active algorithmic actions. Used sparingly as a radiant signal flare.
- **Secondary (`#6366F1` - Machine Indigo):** Identifies predictive trends, neural-net projections, autonomous reorders, and interactive structural elements.
- **Tertiary (`#F59E0B` - Amber Skew):** Flags supply anomalies, lead-time variances, and demand shifts requiring operator sign-off.
- **Critical Warning (`#EF4444` - Stockout Hazard):** Strict highlight for depleted buffers, backorders, and immediate pipeline failures.
- **Background & Surfaces (`#070A11`, `#0B0F19`, `#121826`, `#1B2438`):** Layered cold slate-neutrals providing high-contrast separation without harsh absolute blacks.

## Typography

Typography establishes an analytical dialogue between structural sectioning and tabular telemetry:

- **Headlines (Space Grotesk):** Provides modern geometric structure with slightly engineered glyph details. Used exclusively for dashboard module titles, top-level inventory rollups, and KPI stat headers.
- **Body, Metrics, & Labels (JetBrains Mono):** Drives the operational engine. Every data table, SKU ID, stock level, timeline marker, and percentage differential utilizes monospaced rendering to prevent layout jitter during live-streamed socket updates.
- **Casing Rules:** Secondary labels, metrics flags, and telemetry status items must use uppercase typography with tracking (`0.04em` to `0.08em`) to mimic instrumentation readouts.

## Layout & Spacing

The system runs on a high-density, mathematical 4px grid optimized for maximizing information density without visual collision:

- **Desktop Layout:** 12-column adaptive fluid grid flanked by a collapsed 64px icon dock or a 240px expanded navigation rail. Panels span 3, 4, 6, or 12 columns with strict 16px (`gutter`) alignment.
- **Tablet (768px - 1024px):** 8-column layout. High-level metric cards snap to 2x2 formations, and detailed analytics tables shift to horizontal scroll containers.
- **Mobile (< 768px):** 4-column layout with collapsed margin (`0.75rem`). Operational modules stack linearly into single-column telemetry feeds.
- **Density Rules:** Standard padding within data modules stays compact (`space-sm` to `space-md`), reserving larger vertical spacing (`space-xl`) exclusively for outer viewport separation.

## Elevation & Depth

Elevation rejects diffuse organic dropshadows, relying instead on surface layering, border luminance, and optical glows:

- **Layer 0 (Canvas Base):** Solid deep void (`#070A11`).
- **Layer 1 (Sub-Panels & Data Shelves):** `#0B0F19` framed with a subtle 1px border (`rgba(255, 255, 255, 0.07)`).
- **Layer 2 (Active Cards & Overlays):** `#121826` with 1px active borders (`rgba(99, 102, 241, 0.25)` or `rgba(16, 185, 129, 0.25)`).
- **Telemetry Glow:** Critical anomalies and active toggle states emit an ultra-tight, 4px neon perimeter bloom (`box-shadow: 0 0 8px rgba(16, 185, 129, 0.35)`) signifying hot machine activity.
- **Ghost Dividers:** Internal grid separators use 1px hairlines at `rgba(255, 255, 255, 0.05)` rather than solid color blocks.

## Shapes

In alignment with technical tooling and tactical hardware, all corners employ strict, restrained micro-radii (Soft - Level 1):

- **Primary Enclosures (Cards, Modals, Shelves):** `4px` (`0.25rem`) standard corner radius.
- **Interactive Targets (Buttons, Inputs, Row Selectors):** `2px` to `4px`.
- **Telemetry Badges & Indicators:** `2px` corners; pure pills are reserved strictly for circular binary status pings (e.g., live pipeline indicator lights).
- Avoid soft, bulbous rounding; all geometric junctions must evoke machined precision and industrial control gear.

## Components

### Buttons
- **Primary Operational Button:** Solid emerald (`#10B981`) background, obsidian text (`#070A11`), uppercase JetBrains Mono, 4px radius. Hover triggers an outer neon halo (`0 0 12px rgba(16, 185, 129, 0.45)`).
- **Secondary Command Button:** Transparent fill, 1px perimeter border (`rgba(99, 102, 241, 0.4)`), machine indigo text (`#818CF8`). Hover transitions background to `rgba(99, 102, 241, 0.1)`.
- **Utility / Tertiary Button:** `#121826` surface, muted slate border, ghost text.

### Metric Cards & Telemetry Pods
- Composed of `#0B0F19` base tile, 1px subtle boundary, and `12px` interior padding.
- Top slot contains the KPI descriptor in uppercase `label-sm` along with a micro status ping.
- Value displayed in bold `Space Grotesk` (`headline-lg`), flanked directly below by a monospaced delta tag (`+18.4% DEMAND_SURGE`) and a clean SVG sparkline rendered in `#10B981` or `#EF4444`.

### Data Grids & SKU Tables
- Rigid monospaced tables with fixed header rows in `#070A11` and 1px bottom accent lines.
- Alternating hover row states (`rgba(255, 255, 255, 0.02)`) with a 2px left-side active border indicator when selected.
- Numeric columns strictly right-aligned with tabular numerals (`tnum`).

### Badges & Telemetry Chips
- Compact, angular badges: `font-size: 10px`, `padding: 2px 6px`, 2px border radius.
- Colors mapped to state: Green (Surplus/Optimized), Indigo (Predictive Reorder), Amber (Lead-Time Variance), Red (Critical Stockout).

### Inputs & Selectors
- Recessed background (`#070A11`), 1px structural border (`rgba(255, 255, 255, 0.12)`), text rendered in JetBrains Mono.
- Focus state switches border to `#6366F1` with an inner 1px glow.

### Real-Time Signal Indicators
- Pulsing 6px dots alongside server status and ML inference queues, using continuous CSS keyframe expansion rings for operational feedback.