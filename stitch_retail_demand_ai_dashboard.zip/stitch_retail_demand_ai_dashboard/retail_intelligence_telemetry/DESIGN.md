---
name: Retail Intelligence Telemetry
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#584237'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#8c7164'
  outline-variant: '#e0c0b1'
  surface-tint: '#9d4300'
  primary: '#9d4300'
  on-primary: '#ffffff'
  primary-container: '#f97316'
  on-primary-container: '#582200'
  inverse-primary: '#ffb690'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#565e74'
  on-tertiary: '#ffffff'
  tertiary-container: '#929ab2'
  on-tertiary-container: '#2a3246'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb690'
  on-primary-fixed: '#341100'
  on-primary-fixed-variant: '#783200'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  title-md:
    fontFamily: Space Grotesk
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  metric-display:
    fontFamily: Space Grotesk
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  gutter-desktop: 1.25rem
  margin: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an aggressive, high-contrast trading floor aesthetic tailored for live retail intelligence and real-time algorithmic telemetry. Engineered for retail analytics operators, merchandising strategists, and demand forecasters, the interface delivers high-velocity situational awareness through an architectural fusion of precision data density and technical vitality.

The visual direction merges **Modern Enterprise Utility** with **Experimental High-Contrast Telemetry**:
- **Pristine Precision Canvas:** Structural, crisp surfaces built on clean slates and stark white containers prevent cognitive exhaustion during prolonged surveillance sessions.
- **Kinetic High-Contrast Signal:** Fiery orange signals critical delta shifts, surges, and primary actions, balanced against electric cyan telemetry vectors that map live trendlines, velocity indicators, and active retail pipelines.
- **Architectural Edge Grid:** Monospaced data displays paired with structural, compact radius boundaries evoke the discipline of mission-critical terminal hardware while preserving modern web clarity.

## Colors

The color architecture balances high-luminance canvas backgrounds with electric signal markers to prioritize scan speed and high-density legibility.

### Palette Roles & Hierarchy
- **Primary (`#f97316`):** Kinetic demand signal. Reserved for primary operational actions, active volume surges, anomaly alerts, and breakthrough trend metrics.
- **Secondary (`#06b6d4`):** Live telemetry and forecasting cyan. Used for stream indicators, projection vectors, real-time sync markers, and comparative retail baselines.
- **Tertiary (`#0f172a`):** Deep command slate. Powers top-level headings, dominant KPI figures, high-contrast metric backdrops, and active structural borders.
- **Neutral (`#64748b`):** Precision slate. Drives secondary labeling, metadata, grid borders (`#e2e8f0`), and structural dividers.

### Canvas & Surface Structure
- **Base Canvas:** `#f8fafc` serves as the global application background, reducing glare while maintaining crisp contrast.
- **Surface Elevation 1 (Cards, Modules):** `#ffffff` with razor `#e2e8f0` stroke delineation.
- **Surface Elevation 2 (Nested Inspector Wells):** `#f1f5f9` for table headers, embedded metric blocks, and tool trays.

## Typography

The typographical pairing serves distinct cognitive needs: **Space Grotesk** commands macro layout titles, KPI headers, and alert banners with geometric weight, while **JetBrains Mono** enforces vertical alignment and absolute character precision across transaction streams, telemetry feeds, and inventory grids.

- **Numerics & Tabular Data:** All numerical metrics and SKU telemetry must leverage tabular figures (`tnum`) inside JetBrains Mono to preserve decimal scanning paths down complex ledger tables.
- **Labels & System Tags:** System tags, tickers, and operational badges use uppercase `label-sm` or `label-md` with expanded letter-spacing (`0.05em` to `0.08em`) to mimic trading terminal micro-readouts.

## Layout & Spacing

The layout model uses an enterprise-grade 12-column fluid grid system designed for high data density, dashboard multi-split views, and rapid terminal-style resizing.

### Grid & Density Rules
- **Desktop (1280px+):** 12 columns with `1.25rem` gutters and `2rem` outer margins. Accommodates persistent left utility navigation (collapsed or expanded), multi-chart analytical panes, and live inspection drawers.
- **Tablet (768px - 1279px):** 8 columns with `1rem` gutters and `1.5rem` canvas margins. Charts and data cards reflow to 4-column spans (2 modules per row).
- **Mobile (<768px):** 4 columns with `0.75rem` gutters and `1rem` margins. Modules reflow to single-column blocks; micro-telemetry panels stack vertically with dense `0.5rem` internal gaps.
- **Rhythm Principle:** Internal card padding is standardized to `space-md` (`1rem`) to maximize screen real estate, increasing to `space-lg` (`1.5rem`) only on primary executive summaries.

## Elevation & Depth

Visual hierarchy does not rely on heavy blurs or deep drops. Instead, this design system combines **architectural surface tiers**, **crisp border definitions**, and **calibrated micro-shadows** with tinted slate diffusion.

- **Level 0 (Canvas):** `#f8fafc` flat ground layer.
- **Level 1 (Card & Modular Panes):** `#ffffff` surface, bounded by an exact `1px solid #e2e8f0` border, paired with an ambient micro-shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.04), 0 1px 3px 0 rgba(15, 23, 42, 0.03)`.
- **Level 2 (Interactive Flyouts & Hover States):** `#ffffff` surface elevated via `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)` with active border tinting to `#cbd5e1`.
- **Level 3 (Modals, Overlays, Floating Telemetry Badges):** High-priority focus modules supported by `0 12px 24px -4px rgba(15, 23, 42, 0.12), 0 4px 8px -2px rgba(15, 23, 42, 0.06)`, outlined with `#94a3b8`.
- **Accent Glow Utility:** Critical operational states (active live streams or surge alerts) project a soft edge ring using `0 0 0 1px #f97316, 0 0 12px rgba(249, 115, 22, 0.18)` or cyan variant `0 0 0 1px #06b6d4, 0 0 12px rgba(6, 182, 212, 0.18)`.

## Shapes

The design system employs a **Soft Architectural (`1`)** shape language. All basic interactive targets, inputs, telemetry chips, and modular panels maintain an ultra-tight, clean radius (`0.25rem` / 4px). 

- **Base Components (Buttons, Chips, Inputs, Badges):** `rounded` (`0.25rem` / 4px). This creates crisp, instrument-panel discipline.
- **Container Panes (Data Cards, Modal Dialogs, Data Tables):** `rounded-lg` (`0.5rem` / 8px) with strict inner boundary clipping.
- **Hero Display Panels & Alert Banners:** `rounded-xl` (`0.75rem` / 12px).
- **No Full Pills:** Never use circular pill buttons for standard operational elements; buttons and inputs must maintain defined corners to support high-density alignment.

## Components

### Buttons
- **Primary Button:** Background `#f97316`, foreground `#ffffff`, border `1px solid #ea580c`, font `JetBrains Mono` 12px 600 weight uppercase (`label-md`). Hover: `#ea580c`. Focus: `0 0 0 2px #ffffff, 0 0 0 4px #f97316`.
- **Secondary Telemetry Button:** Background `#ffffff`, foreground `#0f172a`, border `1px solid #cbd5e1`. Hover: Background `#f1f5f9`, border `#94a3b8`. Focus: `0 0 0 2px #ffffff, 0 0 0 4px #06b6d4`.
- **Ghost / Utility Button:** Background transparent, foreground `#64748b`, border `1px solid transparent`. Hover: Background `#f1f5f9`, foreground `#0f172a`.
- **Dimensions:** Height 32px (compact terminal) or 38px (standard desktop action); padding `0 12px`.

### Telemetry Badges & Chips
- **Demand Surge Status:** Background `rgba(249, 115, 22, 0.10)`, text `#ea580c`, border `1px solid rgba(249, 115, 22, 0.25)`.
- **Live Sync Active:** Background `rgba(6, 182, 212, 0.10)`, text `#0891b2`, border `1px solid rgba(6, 182, 212, 0.30)`, with an animated 6px cyan pulse dot.
- **Neutral SKU / Channel Tag:** Background `#f1f5f9`, text `#334155`, border `1px solid #e2e8f0`.

### Data Cards & Modular Panes
- Background `#ffffff`, border `1px solid #e2e8f0`, border-radius `0.5rem`, padding `1rem`. Header rows feature `Space Grotesk` titles paired with right-aligned `JetBrains Mono` sparkline telemetry or interval selectors (`1H`, `24H`, `7D`, `LIVE`).

### Input Fields & Search Bars
- Background `#ffffff`, border `1px solid #cbd5e1`, border-radius `0.25rem`, height 36px, font `JetBrains Mono` 13px. 
- Prefix indicator contains search or scope icons tinted `#64748b`. Focus state triggers border `#f97316` with a crisp `0 0 0 1px #f97316` outline ring.

### Checkboxes & Radios
- **Checkbox:** 16x16px square, radius 2px, border `1px solid #94a3b8`, background `#ffffff`. Checked state: Background `#0f172a`, checkmark `#ffffff`, border `#0f172a`.
- **Radio:** 16x16px circle, border `1px solid #94a3b8`, background `#ffffff`. Checked state: Border `#f97316`, filled with a centered 6px `#f97316` dot.

### Real-Time Ledger & Intelligence Tables
- **Header Row:** Background `#f8fafc`, text `#64748b`, `label-sm` uppercase tracking, bottom border `1px solid #cbd5e1`.
- **Data Rows:** Background `#ffffff`, alternating hover state `#f8fafc`, height 40px, cell divider `1px solid #f1f5f9`. Numbers and currency align right in `JetBrains Mono`.